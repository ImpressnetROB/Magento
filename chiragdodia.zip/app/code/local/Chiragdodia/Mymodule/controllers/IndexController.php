<?php
class Chiragdodia_Mymodule_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        echo "Hello tuts+ World";
    }
    public function testAction()
    {
        echo "test action";
    }
}
